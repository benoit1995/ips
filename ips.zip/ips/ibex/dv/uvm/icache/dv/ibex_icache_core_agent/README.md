# ICache Core UVM Agent

Agent is extended from DV library agent classes.
