#!/bin/bash
rm -rf hwpe_ctrl_lib
