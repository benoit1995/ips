# APB

This repository contains common functions and hardware modules for the Advanced Peripherals Bus (APB).