# APB GPIO

This unit provides a simple GPIO interfac via the APB bus.
It supports up to 32 inputs and outputs. It also supports setting the direction
and the pad configuration (examples would be drive strength, schmitt triggers,
...)
