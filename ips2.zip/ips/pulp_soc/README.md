# pulp_soc

The `pulp_soc` repository contains the structure of the SoC microcontroller
subsystem used in PULPissimo (single-core) and PULP (multi-core) chips.
For more details on the internal architecture, see the README.md in the
`pulpissimo` repository.
