# ICache ECC Agent

This very simple agent can be used to inject single-bit and double-bit errors on the interface of a `prim_ram_1p`, used for checking ECC error detection.
