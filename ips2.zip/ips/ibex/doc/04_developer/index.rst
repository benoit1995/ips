Ibex Developer Guide
====================

Ibex is an open source project and invites everyone to contribute.
The Ibex Developer Guide documents how Ibex is developed, both in terms of process and tools.

Read on if you would like to work with the Ibex code base to fix a bug, add a feature, or reproduce the verification.

.. todo::

   Describe how to set up development environment, how to make changes, etc.
   Use content from various READMEs and the CONTRIBUTING guide in the repo.

.. toctree::
   :maxdepth: 2
   :caption: In this section

   concierge
