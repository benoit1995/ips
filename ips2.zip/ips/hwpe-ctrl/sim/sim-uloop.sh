#!/bin/bash
vsim -work hwpe_ctrl_lib vopt_tb_hwpe_ctrl_uloop

